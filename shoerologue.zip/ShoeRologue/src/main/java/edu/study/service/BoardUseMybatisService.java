package edu.study.service;

import java.util.List;

import edu.study.vo.BoardUseMyBatisVO;

public interface BoardUseMybatisService {
	List<BoardUseMyBatisVO> list() throws Exception;
}
