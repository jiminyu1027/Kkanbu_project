package edu.study.vo;

public class SampleVO {

	private int sidx;
	private String stitle;
	private String scontents;
	private String swriter;
	private String sdate;
	
	
	public int getSidx() {
		return sidx;
	}
	public void setSidx(int sidx) {
		this.sidx = sidx;
	}
	public String getStitle() {
		return stitle;
	}
	public void setStitle(String stitle) {
		this.stitle = stitle;
	}
	public String getScontents() {
		return scontents;
	}
	public void setScontents(String scontents) {
		this.scontents = scontents;
	}
	public String getSwriter() {
		return swriter;
	}
	public void setSwriter(String swriter) {
		this.swriter = swriter;
	}
	public String getSdate() {
		return sdate;
	}
	public void setSdate(String sdate) {
		this.sdate = sdate;
	}
	
	
	
}
